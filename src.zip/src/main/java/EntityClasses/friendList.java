package EntityClasses;

/**
 * Created by dilan_server on 2017-07-19.
 */
public class friendList {

    private String name;
    private String id;
    private String ProfilePictureUrl;
    private String CoverPictureUrl;
    private String dob;


    public friendList( String id,String name, String profilePictureUrl, String coverPictureUrl, String dob) {
        this.name = name;
        this.id = id;
        ProfilePictureUrl = profilePictureUrl;
        CoverPictureUrl = coverPictureUrl;
        this.dob = dob;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProfilePictureUrl() {
        return ProfilePictureUrl;
    }

    public void setProfilePictureUrl(String profilePictureUrl) {
        ProfilePictureUrl = profilePictureUrl;
    }

    public String getCoverPictureUrl() {
        return CoverPictureUrl;
    }

    public void setCoverPictureUrl(String coverPictureUrl) {
        CoverPictureUrl = coverPictureUrl;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }
}
