package Process;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by dilan_server on 2017-01-05.
 */

public class WebServiceReference {

    public static String url = "http://192.168.43.242:9090/Service1/getUserList";
    public static int TimeOut = 30000;
    public static String namespace = "http://Ballerina/";



    public static class getUserList {
        public static String method_name = "getUserList";
        public static String method_url = namespace+method_name;
    }


}
