package Process;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

/**
 * Created by gihanmunasinghe on 7/22/17.
 */

public class getJSON extends AsyncTask {

    public Context c;
    ProgressDialog progressDialog;
    Activity activity;
String rec_value;

    public getJSON(ProgressDialog progressDialog, Activity activity){
        this.progressDialog = progressDialog;
        this.activity = activity;

    }






    @Override
    protected Object doInBackground(Object[] objects) {

        SoapObject request = new SoapObject(WebServiceReference.namespace, WebServiceReference.getUserList.method_name);

//        PropertyInfo para1 = new PropertyInfo();
//
//        para1.setName("name");
//        request.addProperty(para1);

        SoapSerializationEnvelope w_version = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        w_version.setOutputSoapObject(request);
        HttpTransportSE httpTransportSE = new HttpTransportSE(WebServiceReference.url, WebServiceReference.TimeOut);
        try {
            httpTransportSE.call(WebServiceReference.getUserList.method_url, w_version);

            rec_value = w_version.getResponse().toString();
            System.out.println("Testing0");


            System.out.println(rec_value);
            System.out.println("Testing1");


        } catch (Exception e) {
            e.printStackTrace();
        }



        return null;
    }




}