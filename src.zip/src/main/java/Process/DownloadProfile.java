package Process;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

/**
 * Created by dilan_server on 2017-07-21.
 */
public class DownloadProfile extends AsyncTask<String,String,String>{

    public Context c;
    ProgressDialog progressDialog;
    Activity activity;
    //private String downloadUrl = "http://www.9ori.com/store/media/images/8ab579a656.jpg";

    public DownloadProfile(ProgressDialog progressDialog, Activity activity){
        this.progressDialog = progressDialog;
        this.activity = activity;
    }

    @Override
    protected String doInBackground(String... param) {







        return null;
    }




}
