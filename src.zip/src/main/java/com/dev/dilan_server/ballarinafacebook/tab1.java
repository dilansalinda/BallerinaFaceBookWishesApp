package com.dev.dilan_server.ballarinafacebook;

/**
 * Created by dilan_server on 2017-07-17.
 */

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;

import EntityClasses.friendList;

import java.io.InputStream;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class tab1 extends Fragment {

    Spinner spinner;
    ListView listView;
    friendListAdapter arrayAdapter;
    ProgressDialog mProgressDialog;
    String URL ="d";
    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab1, container, false);

        //spinner = (Spinner)rootView.findViewById(R.id.categorys);
        listView = (ListView)rootView.findViewById(R.id.listView);
        StrictMode.ThreadPolicy md = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(md);

        arrayAdapter = new friendListAdapter(inflater.getContext(),R.layout.list_item);
        listView.setAdapter(arrayAdapter);
        listView.setDividerHeight(2);

//        final ArrayAdapter<CharSequence> adapter =
//        ArrayAdapter.createFromResource(inflater.getContext(),R.array.mycategorys, android.R.layout.simple_spinner_item);
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinner.setAdapter(adapter);

        String sampleJSON = "{\n" +
                "  \"data\": [\n" +
                "    {\n" +
                "      \"birthday\": \"07/05\",\n" +
                "      \"name\": \"Chamara Sasmith\",\n" +
                "      \"id\": \"690688854330423\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"birthday\": \"03/11/1994\",\n" +
                "      \"name\": \"Sasi Prabath Piyuman\",\n" +
                "      \"id\": \"707784499295606\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"birthday\": \"03/11/1994\",\n" +
                "      \"name\": \"Charith Malinda\",\n" +
                "      \"id\": \"473850732757414\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"birthday\": \"09/12/1994\",\n" +
                "      \"name\": \"Gihan Munasinghe\",\n" +
                "      \"id\": \"687667321381279\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"birthday\": \"07/15\",\n" +
                "      \"name\": \"Tharindi Wasana\",\n" +
                "      \"id\": \"174616739743935\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"paging\": {\n" +
                "    \"cursors\": {\n" +
                "      \"before\": \"QVFIUlNMUGw2X3BPLVlwaGhLUldyUDRuQkpMT09TbGduQjNjeW9KSFdpY1p3RjZAoUmlnSWxYUVFKQUVCY1BJVHZA0bTBXQ2JVaHJsVTBFeXNoZATdCT3g1dWZAB\",\n" +
                "      \"after\": \"QVFIUnRiNEZAVRGZASVDkzamk1VzJKQkhucWxJaEhYWVZAfLWxzSjUzZAm1mMUN4SV9jVW9yYXUySkJMN2ZAmcnE0bUlHMWxrUEcwVEVsUXBjSXBsUXhKU2psZADNn\"\n" +
                "    }\n" +
                "  },\n" +
                "  \"summary\": {\n" +
                "    \"total_count\": 219\n" +
                "  }\n" +
                "}";

        try {

            JSONObject recivedObject = new JSONObject(sampleJSON);
            String friendList = recivedObject.get("data").toString();

            JSONArray friendListJSONArray = new JSONArray(friendList);

            String name;
            String id;
            String dob;

            for (int i = 0; i < friendListJSONArray.length(); i++) {
                name = friendListJSONArray.getJSONObject(i).getString("name");
                id = friendListJSONArray.getJSONObject(i).getString("id");

                    dob = friendListJSONArray.getJSONObject(i).getString("birthday");


                EntityClasses.friendList d =
                        new friendList(id,name,null,null,dob);
                arrayAdapter.add(d);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


        return rootView;
    }



}
