package com.dev.dilan_server.ballarinafacebook;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;



public class Login extends AppCompatActivity {

    SharedPreferences myShared;
    SharedPreferences.Editor editor;
        public static AccessToken accessToken;
    public static final String IS_LOGIN = "IsLoggedIn";
    public static int PRIVATE_MODE = 0;

    LoginButton loginButton;
    TextView textView;
    CallbackManager callbackManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_login);

        StrictMode.ThreadPolicy tt = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(tt);

        loginButton = (LoginButton)findViewById(R.id.login_button);
        textView = (TextView)findViewById(R.id.status);

        callbackManager = CallbackManager.Factory.create();
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

                 accessToken = loginResult.getAccessToken();

                textView.setText("Login Ok \n" +loginResult.getAccessToken().getUserId() +"\n "+ loginResult.getAccessToken().getToken());
                //Add shared Preferences
                myShared = getSharedPreferences("Login Credentials", PRIVATE_MODE);
                editor = myShared.edit();
                editor.putBoolean(IS_LOGIN, true);
                editor.putString("AccessToken", loginResult.getAccessToken().getToken());
                editor.putString("userID", loginResult.getAccessToken().getUserId().toString());
                editor.commit();
                System.out.println("WWW- "+loginResult);

                    Intent i = new Intent(Login.this,MainActivity.class);
                    startActivity(i);




            }


//            public boolean isLoggedIn() {
//                AccessToken accessToken = AccessToken.getCurrentAccessToken();
//                return accessToken != null;
//            }


            @Override
            public void onCancel() {
                textView.setText("Login Cancel");
            }

            @Override
            public void onError(FacebookException error) {
                textView.setText("Login error");
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode,resultCode,data);
    }
}
