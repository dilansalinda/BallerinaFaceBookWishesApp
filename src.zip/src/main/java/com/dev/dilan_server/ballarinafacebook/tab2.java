package com.dev.dilan_server.ballarinafacebook;

/**
 * Created by dilan_server on 2017-07-17.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;

public class tab2 extends Fragment {
    Spinner spinner;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab2, container, false);
        spinner = (Spinner)rootView.findViewById(R.id.categorys);

        final ArrayAdapter<CharSequence> adapter =
        ArrayAdapter.createFromResource(inflater.getContext(),R.array.mycategorys, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        return rootView;
    }


}
