package com.dev.dilan_server.ballarinafacebook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import EntityClasses.friendList;

/**
 * Created by dilan_server on 2017-07-19.
 */
public class friendListAdapter extends ArrayAdapter {

    List list = new ArrayList();
    public static  ArrayList<String> flist = new ArrayList();

        public friendListAdapter(Context context, int resource) {
            super(context, resource);
    }

    @Override
    public void add(Object object) {
        super.add(object);
        list.add(object);
    }


    @Override
    public int getCount() {
        return list.size();
    }



    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View row;
        row = convertView;
        final friendHoder friendHoder;

        if(row == null){
            LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = layoutInflater.inflate(R.layout.list_item,parent,false);
            friendHoder = new friendHoder();
            friendHoder.name = (TextView) row.findViewById(R.id.friend_name);
            friendHoder.checkBox = (CheckBox) row.findViewById(R.id.checkbox);
            friendHoder.dob = (TextView) row.findViewById(R.id.friend_dob);
            row.setTag(friendHoder);
        }else{
            friendHoder = (friendHoder) row.getTag();
        }

        final friendList friendList = (EntityClasses.friendList) this.getItem(position);

        friendHoder.name.setText(friendList.getName());
        friendHoder.dob.setText(friendList.getDob());
        friendHoder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (friendHoder.checkBox.isChecked()) {

                  flist.add(friendList.getName());

                } else {

                    System.out.println("No select");
                }
            }
        });

        return row;
    }



    private class friendHoder{
        TextView name,dob,id;
        CheckBox checkBox;

    }


}
