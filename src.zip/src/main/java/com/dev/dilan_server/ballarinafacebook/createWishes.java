package com.dev.dilan_server.ballarinafacebook;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.lang.reflect.Modifier;

public class createWishes extends AppCompatActivity {
Spinner spinner;
Button button;
    ListView listView;
    ArrayAdapter arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_wishes);


        spinner = (Spinner) findViewById(R.id.sp);
        button  = (Button) findViewById(R.id.button2);
        listView = (ListView) findViewById(R.id.listView2);
        listView.setDividerHeight(0);
        arrayAdapter = new ArrayAdapter(createWishes.this, android.R.layout.simple_spinner_item,friendListAdapter.flist);
        listView.setAdapter(arrayAdapter);

        final ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(createWishes.this,R.array.d, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog alertDialog = new AlertDialog.Builder(createWishes.this).create();
                alertDialog.setTitle("Infomation");
                alertDialog.setMessage("Your wish will post!");
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                                startActivity(new Intent(createWishes.this,MainActivity.class));
                            friendListAdapter.flist.clear();

                            }
                        });

                alertDialog.show();


            }
        });


    }
}
