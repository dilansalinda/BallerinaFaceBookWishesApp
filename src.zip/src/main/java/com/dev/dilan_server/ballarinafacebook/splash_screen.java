package com.dev.dilan_server.ballarinafacebook;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;

import org.json.JSONArray;

import Process.DownloadProfile;

public class splash_screen extends AppCompatActivity {

    private final int SPLASH_DISPLAY_LENGTH = 800;
    ImageView logo;
    ProgressDialog progressDialog;
AccessToken accessToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //add logo
        logo = (ImageView) findViewById(R.id.splash_logo);
        //add animation
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.fade_out);
        logo.setAnimation(animation);

        //check if already sign in
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                SharedPreferences sh_Pref = getSharedPreferences("Login Credentials", Login.PRIVATE_MODE);
                boolean check = sh_Pref.getBoolean(Login.IS_LOGIN, false);
                System.out.println("OOOOOOOO - "+ check);

                if (check) {


                    DownloadProfile downloadProfile = new DownloadProfile(progressDialog,splash_screen.this);
                    downloadProfile.c = splash_screen.this ;
                    downloadProfile.execute("asd");

                    GraphRequest request = GraphRequest.newMyFriendsRequest(
                            Login.accessToken,
                            new GraphRequest.GraphJSONArrayCallback() {
                                @Override
                                public void onCompleted(JSONArray array, GraphResponse response) {
                                    Toast.makeText(splash_screen.this, array.toString(), Toast.LENGTH_SHORT).show();
                                }
                            });

                    request.executeAsync();



                    Intent intent = new Intent(splash_screen.this,MainActivity.class);
                    startActivity(intent);
                    splash_screen.this.finish();
                } else {
                    System.out.println("DDDDDDDDDDDDDD");
                    Intent intent = new Intent(splash_screen.this, Login.class);
                    startActivity(intent);
                    splash_screen.this.finish();
                }

            }
        },SPLASH_DISPLAY_LENGTH);
    }
}